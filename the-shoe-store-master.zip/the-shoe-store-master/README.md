# The Shoe Store

Android app made for Udacity's Android Kotlin Developer Nanodegree.

Project 1: Build a Shoe Store Inventory App

This app was created for educational purposes only.